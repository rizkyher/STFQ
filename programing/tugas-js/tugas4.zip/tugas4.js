//variable dari local storage
var allUserJSON = localStorage.getItem("allUsers");
// json ke array object
var allUsersArr = JSON.parse(allUserJSON);
//update storage
function update_storage() {
    //array jadi json
    var allUserJSON = JSON.stringify(allUsersArr);
    // simpan ke LS
    localStorage.setItem("allUsers", allUserJSON);
}

function register(){
    // ambil data dari form
    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;

    //cek data username di array
    if (username != allUsersArr && password != allUsersArr){
        // jika tidak simpan data array ke storage
        //allUsersArr.push(username,password)
        localStorage.setItem("allUsers", JSON.stringify(allUsersArr)) ;
        update_storage()
    } else {
        // jika ada tampilkan error
        alert("username sudah ada")
    }
}

function login(){
    //ambil data dari form
    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;

    // cek apakah username ada di allusersarr
    if (allUsersArr.includes(username.value)) {
        // cek pass
        if (allUsersArr.includes(password.value)) {
            // jika pass sama
            alert("berhasil login")
        }
    } else {
        // jika tidak
        alert("username tidak ada")
    }
}
