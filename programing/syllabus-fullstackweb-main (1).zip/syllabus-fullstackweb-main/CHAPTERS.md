# CHAPTERS

- [Chapter 0: Preparation](chapters/CHAPTER-0.md)
- [Chapter 1: Frontend Web Design](chapters/CHAPTER-1.md)
- [Chapter 2: Frontend Web Application](chapters/CHAPTER-2.md)
- [Chapter 3: Frontend Web Application](chapters/CHAPTER-3.md)
- [Chapter 4: Interactive Web Application](chapters/CHAPTER-4.md)
- [Chapter 5: Modern Web Application](chapters/CHAPTER-5.md)
- [Chapter 6: Data and Backend API](chapters/CHAPTER-6.md)
