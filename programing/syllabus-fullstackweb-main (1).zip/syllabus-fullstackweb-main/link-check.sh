find . -name CHAPTER-0.md -exec markdown-link-check -p -q --config link-config.json {} \;
