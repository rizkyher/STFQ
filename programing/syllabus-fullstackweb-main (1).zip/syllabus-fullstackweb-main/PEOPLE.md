# PEOPLE

- Grace Hopper
- Robert Cecil Martin (Uncle Bob)
- Ariya Hidayat
- Martin Fowler
