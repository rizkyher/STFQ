# GLOSSARY

## Concatenate

- EN: Combine or link things together in a chain or series.
- ID: Menggabungkan and menyambungkan beberapa hal dalam rangkaian.

## Concatenation

- EN: A series of interconnected things or events.
- ID: Serangkaian hal atau peristiwa yang saling terkait.
