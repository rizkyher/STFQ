# BOOKS

- Clean Code by Robert C. Martin (Uncle Bob)
- The Clean Coder: A Code of Conduct for Professional Programmers by Robert C. Martin (Uncle Bob)
- Refactoring by Martin Fowler
- Design Patterns: Elements of Reusable Object-Oriented Software by Erich Gamma, Richard Helm, Ralph Johnson, & John Vlissides
- Domain-Driven Design: Tackling Complexity in the Heart of Software by Eric Evans
- Soft Skills: The Software Developer’s Life Manual by John Sonmez
- Clean Architecture by Robert C. Martin (Uncle Bob)
- The Effective Engineer by Edmond Lau
- The Pragmatic Programmer by Andrew Hunt & David Thomas
