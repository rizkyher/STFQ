# Chapter 8: Final Project Presentation

Get ready to present your final project in the graduation day.

### Units

- Project Launch
- Presentation Rehearsal
- Progress Evaluation
- Presentation
- Graduation Day

### Projects

- [Final Project Presentation](projects/final-project-presentation.md)
- [Graduation](projects/graduation.md)
