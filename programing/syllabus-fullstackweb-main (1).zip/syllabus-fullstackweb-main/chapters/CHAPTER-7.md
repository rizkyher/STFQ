# Chapter 7: Final Project Development

Build final project with your team members until graduation day.

### Units

- Final Project Team Structure
- Final Project Idea
  - Take some inspiration
- Final Project Presentation
  - Create a slide
- Final Project Demo

### Projects

- Create Full Stack Web Application
- Present Full Stack Web Application
