# Chapter Infinity: Career Development

There are unlimited actions to upgrade your self.

- Improve hard and soft skills
- Improve CV, resume, and portfolios
- Improve online profiles (Website, GitHub, LinkedIn, Facebook)
- Improve public speaking
- Participate in community activities
- Apply and get a job as a professional
- Build your own tech startup
- Connect with alumni, network, or current participants
- Apply for a job or opportunity
- Start entrepreneurship journey
- Join various events by many communities
- Product development consultation
