# HTML Metadata

- Favicon
- OpenGraph
