# Domain Registry

## Providers

![](images/domain-registry-uniregistry.png)

![](images/domain-registry-uniregistry-2.png)

![](images/domain-registry-namecheap.png)

![](images/domain-registry-qwords.png)

International:

- Uniregistry
- NameCheap

Local:

- QWords
