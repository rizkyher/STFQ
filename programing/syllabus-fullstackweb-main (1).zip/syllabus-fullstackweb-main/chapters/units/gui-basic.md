# Graphical User Interface (GUI) Basic

## GUI Examples

![](images/gui-basic.png)

- Easy to Use
- Colorful Interface
- Clickable Panels and Buttons
- Animated Screens
- Installation Wizard
