# Testing

## Testing References

- [7 Myths About Software Testing – GO-JEK Product + Tech](https://blog.gojekengineering.com/7-myths-about-software-testing-11906cc4356e)
