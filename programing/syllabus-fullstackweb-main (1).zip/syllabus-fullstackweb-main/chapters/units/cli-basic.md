# Command Line Interface (CLI) Basic

## CLI Examples

![](images/cli-basic.jpg)

## CLI Terminologies

- Terminal
- Shell
- Prompt: Command Typing Area
- Programmable Actions
