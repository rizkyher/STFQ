# Preparation Guide

Please read through the [given coding preparation guide](https://bit.ly/coding-preparation).

![](images/preparation-guide.png)
