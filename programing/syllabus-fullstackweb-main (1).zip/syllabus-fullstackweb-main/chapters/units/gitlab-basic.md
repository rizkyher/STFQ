# GitLab Basic

[GitLab](https://gitlab.com)

![](images/gitlab-basic-1.png)

![](images/gitlab-basic-2.png)
