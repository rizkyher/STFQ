# Node.js Auth

## Node.js Auth References

- [JSON Web Token (JWT) Authentication with Node.js and Auth0 from @joel\_\_lord on @eggheadio](https://egghead.io/courses/json-web-token-jwt-authentication-with-node-js-and-auth0)
