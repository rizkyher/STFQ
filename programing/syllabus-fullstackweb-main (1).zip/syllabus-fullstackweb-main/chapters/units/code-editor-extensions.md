# Code Editor Extensions

## Prettier

Prettier to format variety of code files, especially:

- HTML
- CSS
- JavaScript
