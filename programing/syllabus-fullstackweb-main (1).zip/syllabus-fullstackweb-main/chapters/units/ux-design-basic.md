# UX Design Basic

## UX Design Examples

### Content Model

![](images/ux-content-model.jpg)

### User Journey Map

![](images/ux-user-journey-map.jpg)

### Customer Journey Map

![](images/ux-customer-journey-map.png)

![](images/ux-app-journey.webp)

## UX Design Basic References

- [ReallyGoodUX](https://www.reallygoodux.io)
