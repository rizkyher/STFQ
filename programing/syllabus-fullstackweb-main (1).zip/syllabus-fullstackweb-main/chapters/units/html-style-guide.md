# HTML Style Guide

- [Google HTML/CSS Style Guide](https://google.github.io/styleguide/htmlcssguide.html)
- [w3schools HTML5 Style Guide](https://www.w3schools.com/html/html5_syntax.asp)
