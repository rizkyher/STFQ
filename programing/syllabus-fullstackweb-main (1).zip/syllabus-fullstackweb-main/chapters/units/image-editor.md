# Image Editor

- [Inkscape](https://inkscape.com) vs Adobe Illustrator
- [GIMP](https://gimp.org) vs Adobe Photoshop
