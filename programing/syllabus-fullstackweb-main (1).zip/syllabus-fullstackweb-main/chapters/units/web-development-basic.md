# Web Development Basic

- [Introduction to Web Development - Hackr.io](https://hackr.io/documents/webdev-ebook.pdf) (PDF) 📖
- [Getting Real - Basecamp](https://basecamp.com/books/getting-real) (Ebook) 📖
