# UI Design Tools

- [Figma](https://figma.com)
  - [Figma's Help Center](https://help.figma.com)
  - [The Beginner's Guide to Figma from @jsjoeio on @eggheadio](https://egghead.io/courses/the-beginner-s-guide-to-figma)
- [Sketch](https://www.sketchapp.com)
- [Framer](https://framer.com)
- [Gravit.io](https://gravit.io)
- [Affinity Designer](https://affinity.serif.com)
- [Adobe XD](https://www.adobe.com/sea/products/xd.html)
- [Full Page Screen Capture - Chrome Web Store](https://chrome.google.com/webstore/detail/full-page-screen-capture/fdpohaocaechififmbbbbbknoalclacl)
