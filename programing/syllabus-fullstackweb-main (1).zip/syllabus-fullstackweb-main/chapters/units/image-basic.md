# Image Basic

- Bitmap vs Vector
- File Types: JPG, PNG, PDF, GIF, SVG
