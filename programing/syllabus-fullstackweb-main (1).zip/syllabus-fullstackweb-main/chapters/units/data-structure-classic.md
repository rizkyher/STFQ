# Data Structure Classic

- Stack
- Queue
- Linked List
- Dictionary
- Set
- Binary Tree
- Graph
- Hash Table
