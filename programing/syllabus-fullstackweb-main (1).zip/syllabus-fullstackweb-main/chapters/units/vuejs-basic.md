# Vue.js Basic

- [Vue.js Handbook](https://vuehandbook.com)
- [Vue.js Handbook by Flavio Copes (PDF)](https://drive.google.com/open?id=1tyTNux2-az1yn-PsT8k7OOZTcRCBIb92)
