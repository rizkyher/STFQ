# CSS Library

## Animation

- [Animate.css](https://github.com/daneden/animate.css)
- Animista.net
- Tilomitra.github.io/infinite
- Minimamente.com/project/magic
- Pavlyukpetr.com/awesome
- Greensock.com

## Framework

- Getbootstrap.com
- Bulma.com
- Materializecss.com

