# JavaScript FP

## JavaScript FP References

- [Just Enough Functional Programming in JavaScript from @kyleshevlin on @eggheadio](https://egghead.io/courses/just-enough-functional-programming-in-javascript)
