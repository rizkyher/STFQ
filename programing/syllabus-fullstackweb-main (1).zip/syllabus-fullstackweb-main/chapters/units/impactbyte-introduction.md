# Impact Byte Introduction

[Introduction Slide](https://docs.google.com/presentation/d/1Ws_CAYC0sXNnsHg1WrMIW_MPy6uy3D3j4bTwqnRLRCk/edit#slide=id.g2404581aa9_0_79) (Google Slide) 📺
