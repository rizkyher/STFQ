# Project React Website

- Create a new repo for the project: `project-react-website`
- Generate or scaffold the React app using `create-react-app`
- Structure, modify, create, and use the component files
- Feel free to ideate the website by your self, but it has to be a website, not just some experiments
- Push changes to GitHub and submit your project
