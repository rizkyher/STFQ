# Setup GitLab Account

- Sign Up for a GitLab account
- Use a readable username
- Fill the form
- Click Sign Up button
- Verify your email address
- You will need to accept the invitation to join:
  - GitLab of Impact Byte Learn
    - https://gitlab.com/impactbyte/learn
    - https://gitlab.com/impactbyte/learn/course-fullstackweb
