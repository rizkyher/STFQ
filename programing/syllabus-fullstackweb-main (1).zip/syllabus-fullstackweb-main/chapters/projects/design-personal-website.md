# Design Personal Website

## Figma

- Create Figma account
- Create new team
- Create new team projects
- Choose the project
- Create new file in the project
- Load the file...
- Name the file as "Personal Website"
- Create a frame
- Choose design as Desktop
- Place design elements inside the frame, not outside
- Place text
- Place variety of shapes (rectangle, circle, line)
- Place image
- Share the file using the "Share" button
- Copy the link of the Figma file to GitHub Issues assigned to you
- Export the frame as PNG if you need
