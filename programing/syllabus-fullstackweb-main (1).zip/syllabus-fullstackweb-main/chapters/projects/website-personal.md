# Website Personal

- https://onepagelove.com/gallery/portfolio
- https://onepagelove.com/gallery/personal
- https://onepagelove.com/gallery/resume
