# Project React

- Create a new repo for the project: `project-react`
- Generate or scaffold the React app using `create-react-app`
- Structure, modify, create, and use the component files
- Push changes to GitHub and submit your project
