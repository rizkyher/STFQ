# Project React Form

- Create a new repo for the project: `project-react-form`
- Generate or scaffold the React app
- Structure, modify, create, and use the component files
- Feel free to ideate the app by your self, but it has to be an application that has some data within `state` and `props`, not just a regular website
- You have to communicate the data between `form` and `input` with `state` and `props`
- Push changes to GitHub and submit your project
