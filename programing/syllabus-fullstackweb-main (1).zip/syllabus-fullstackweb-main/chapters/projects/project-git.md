# Project Git

- Create a public repo on GitHub in your account
  - You can use the existing repo: `project-markdown`, `project-git`, or `yourname.com`
- Push the repo from your local to that GitHub repo
- Submit the repo to GitHub Issues
