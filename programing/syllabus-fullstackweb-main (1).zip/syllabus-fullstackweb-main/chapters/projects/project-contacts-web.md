# Project Contacts Web

Contacts is a simple application to store and manage people's contacts. Just like an address book in your phone or email.

A complete Contacts app should able to:

- See a blank page if there is no contact
- Show all contacts if there is a data
- Perform to add more data
- Fill a new contact data
- Save or store new contact data
- Each contact can contains people's name, phone, email, website, birth date, address, etc.
- Search or filter contacts based on variety of parameters
- Remove specific contact
- Update contact's data
