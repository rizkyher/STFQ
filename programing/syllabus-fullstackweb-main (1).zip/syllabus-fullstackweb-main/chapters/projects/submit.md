# How to Submit Projects

- Make your GitLab and GitHub account has been created
- GitLab is only to access the learning course
- GitHub is for anything around project submission, discussion, code review, etc
- Submit your links, progress, or submission based on the corresponding GitHub Issues assigned by the mentors
- We will evaluate our learning together in the end of the day
