# Setup Laptop and Accounts

Install and make sure you have:

- Say hello in WhatsApp group
  - For confirming your contact
- Access to Internet
  - For enabling access
- Google Chrome
  - For browsing the web
- Fill the [**Participant Skills Survey**](https://bit.ly/impactbyte-skills-survey) 📝
- Confirm email address to receive Getting Real ebook
- Accept Basecamp invitation
  - For communicating with Impact Byte team in a managed way.
- Accept Airtable invitation
  - For your reference, you can access our data of the participants and alumni.

Other things will be installed along the way.
