# Project Setup Domain

- Go to one of the most popular domain registry such as Uniregistry
- You can search for your desired domain name and Top Level Domain (TLD) extension, e.g.: `yourname.com`, `companyname.org`, `name.dev`, etc
- It's recommended to register an account first before buying the domain
- After logged in, you can search and checkout to buy the domain
- Proceed to pay for the domain, the domain will be valid at least 1 year
- After the payment is success, you are now have your own domain!
