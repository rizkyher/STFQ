# Project React Data

- Create a new repo for the project: `project-react-data`
- Generate or scaffold the React app using `create-react-app`
- Structure, modify, create, and use the component files
- Feel free to ideate the app by your self, but it has to be an application that has some data within `state` and `props`, not just a regular website
- Push changes to GitHub and submit your project
