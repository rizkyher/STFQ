# Design Anything

## Figma

- Create new file in existing or new project
- Load the file...
- Name the file as you want
- Design any website or app that you want
- Copy the link of the Figma file to GitHub Issues assigned to you
- Paste the exported mockups into your submission as well
