# Project Calculator Web

Calculator is a popular application to calculate numbers with variety of mathematical operations.

A complete Calculator app should able to do:

- Display and show what can we do with the calculator
  - result area
  - buttons
- Addition: Add two numbers
- Subtraction: Substract two numbers
- Multiplization: Multiply two numbers
- Division: Divide two numbers
- Equal: Calculate the operation, then display the result
