# Project Code Editor

- Install VS Code
- Create folder to contain all projects
- Create a project folder
- Open the project folder
- Create new file in the folder
- Open the file
- Type some texts in the file
