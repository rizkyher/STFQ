# Project React Redux

- Create a new repo for the project: `project-react-redux`.
- Generate or scaffold a simple React app.
- Here we can have a lot of components and reducers.
- Structure, modify, create, and use the components and functions to implement an intergrated React application with Redux architecture.
- Push changes to GitHub and submit your project
